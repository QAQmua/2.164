// 📄 替换文件：AppCore (核心系统与桌面)/DesktopAnimations.swift
import SwiftUI

// 📄 桌面编辑模式抖动动画修饰器
struct JiggleModifier: ViewModifier {
    let isEditing: Bool
    var isWidget: Bool = false
    var customDelayIndex: Int = 0
    
    @State private var wiggle: Bool = false
    
    private var angle: Double { isWidget ? 0.65 : 1.15 }
    
    func body(content: Content) -> some View {
        content
        // 🌟 第一把锁：数学锁
        // 只要 isEditing 是 false，结果强行恒定为 0。
        // 从源头掐断 wiggle 残留带来的数值波动。
            .rotationEffect(.degrees(isEditing ? (wiggle ? angle : -angle) : 0))
        
        // 🌟 第二把锁：动画锁 (核心修复)
        // 纯声明式绑定：只要退出编辑，此处的动画描述会瞬间降级为 .spring()
        // SwiftUI 的依赖图会自动把底层图层遗留的 repeatForever 给清零回收掉，绝不残留僵尸动画！
            .animation(
                isEditing 
                ? .easeInOut(duration: 0.13).repeatForever(autoreverses: true) 
                : .spring(response: 0.25, dampingFraction: 0.6),
                value: wiggle
            )
        
        // 🌟 第三把锁：状态锁
        // 处理 isEditing 自身的丝滑回正过渡
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: isEditing)
        
        // 引擎点火与熄火
            .task(id: isEditing) {
                if isEditing {
                    let delay = customDelayIndex.isMultiple(of: 2) ? 0.0 : 0.06
                    if delay > 0 {
                        try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
                    }
                    guard !Task.isCancelled else { return }
                    wiggle = true
                } else {
                    wiggle = false
                }
            }
            .onAppear {
                // 托底保护：防止视图被 TabView 彻底卸载又挂载时，变量出现假死残留
                if !isEditing {
                    wiggle = false
                }
            }
    }
}

// 📄 小组件删除减号徽章
struct WidgetDeleteBadge: View {
    var body: some View {
        let s = uiScale
        ZStack {
            Circle().fill(.ultraThinMaterial).frame(width: 24.0 * s, height: 24.0 * s)
            Circle().fill(Color.black.opacity(0.45)).frame(width: 24.0 * s, height: 24.0 * s)
            Image(systemName: "minus").font(.system(size: 11.0 * s, weight: .black)).foregroundColor(.white)
            Circle().stroke(Color.white.opacity(0.32), lineWidth: 0.8 * s).frame(width: 24.0 * s, height: 24.0 * s)
        }
        .shadow(color: Color.black.opacity(0.2), radius: 6.0 * s, x: 0, y: 3.0 * s)
    }
}
