// 📄 完整替换文件：AppCore (核心系统与桌面)/HomeScreenView.swift
import SwiftUI
import PhotosUI

// 🌟 修复后：物理隔离材质层，解决 iPhone OLED 屏幕高光吞噬灰色的 Bug
extension View {
    @ViewBuilder
    func applyLiquidGlassEffect<S: InsettableShape>(in shape: S) -> some View {
        self.background {
            if #available(iOS 26.0, *) {
                Color.clear.glassEffect(.clear, in: shape)
            } else {
                Color.clear.background(.ultraThinMaterial, in: shape)
            }
        }
    }
    
    @ViewBuilder
    func applyNativeAdaptiveGlass<S: InsettableShape>(isWhite: Bool, in shape: S) -> some View {
        self.background {
            if isWhite {
                if #available(iOS 26.0, *) {
                    Color.clear
                        .background(Color.black.opacity(0.18), in: shape)
                        .glassEffect(.clear, in: shape)
                } else {
                    Color.clear
                    // 1. 使用 .regularMaterial，但强制深色模式抵消 OLED 刺眼的白光
                        .background(
                            Rectangle()
                                .fill(.regularMaterial)
                                .environment(\.colorScheme, .dark)
                                .clipShape(shape)
                        )
                    // 2. 弃用 .background 叠加颜色，改用 .overlay 从上方压制
                    // 3. 使用 .darken 变暗混合模式，对抗 OLED 高光穿透
                        .overlay(
                            Color.black.opacity(0.15)
                                .blendMode(.darken),
                            in: shape
                        )
                }
            } else {
                // 风景/深色壁纸下：纯正原生超薄玻璃
                if #available(iOS 26.0, *) {
                    Color.clear.glassEffect(.clear, in: shape)
                } else {
                    Color.clear.background(.ultraThinMaterial, in: shape)
                }
            }
        }
    }
}

// 📄 桌面壁纸容器
struct HomeWallpaperBackgroundView: View {
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    
    var body: some View {
        Group {
            if let img = wallpaperManager.homeScreenImage {
                Image(uiImage: img).resizable().scaledToFill()
            } else {
                NativeImage(data: wallpaperManager.homeScreenData)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipped()
    }
}

// 🌟 原生 iOS 流体缩放视窗（防横滑误触、底栏可点可横滑、上推退出、四角悬浮不切边）
struct FluidIOSAppWindow<Content: View>: View {
    let screenW: CGFloat
    let screenH: CGFloat
    @Binding var isActive: Bool
    @Binding var appProgress: CGFloat
    @ViewBuilder let content: () -> Content
    
    @ObservedObject var appearance = SystemAppearance.shared
    
    @State private var dragOffset: CGSize = .zero
    @State private var isDismissing: Bool = false
    @State private var isDismissDragActive: Bool = false
    @State private var dragDirectionDetermined: Bool = false
    
    private var scale: CGFloat {
        if isDismissing { return 0.15 }
        return 1.0 - (appProgress * 0.30)
    }
    
    private var topMargin: CGFloat {
        if isDismissing { return screenH * 0.25 }
        return appProgress * (55.0 * uiScale)
    }
    
    private var offsetY: CGFloat {
        if isDismissing { return -screenH * 0.16 }
        return topMargin - (screenH * (1.0 - scale) / 2.0)
    }
    
    private var offsetX: CGFloat {
        if isDismissing { return 0 }
        return dragOffset.width * 0.20
    }
    
    private var cornerRadius: CGFloat {
        if isDismissing { return 52 }
        return 38.0 + (appProgress * 14.0)
    }
    
    var body: some View {
        ZStack(alignment: .bottom) {
            content()
                .frame(width: screenW, height: screenH)
                .background(Color(UIColor.systemBackground))
                .scrollDisabled(isDismissDragActive || isDismissing)
            
            if isDismissDragActive || isDismissing {
                Color.black.opacity(0.0001)
                    .frame(width: screenW, height: screenH)
                    .contentShape(Rectangle())
            }
            
            Capsule()
                .fill(Color.primary.opacity(0.35))
                .frame(width: 135.0 * uiScale, height: 5.0 * uiScale)
                .padding(.bottom, 9.0 * uiScale)
                .opacity(appearance.hideHomeIndicator ? 0.0 : 1.0)
                .allowsHitTesting(false)
        }
        .frame(width: screenW, height: screenH)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .scaleEffect(scale, anchor: .center)
        .offset(x: offsetX, y: offsetY)
        .opacity(isDismissing ? 0.0 : 1.0)
        .shadow(color: Color.black.opacity(Double(appProgress * 0.28)), radius: 25 * appProgress, y: 12 * appProgress)
        .position(x: screenW / 2, y: screenH / 2)
        .ignoresSafeArea(.all)
        .simultaneousGesture(
            DragGesture(minimumDistance: 6, coordinateSpace: .global)
                .onChanged { val in
                    guard !isDismissing else { return }
                    
                    let dx = val.translation.width
                    let dy = val.translation.height
                    let totalDistance = hypot(dx, dy)
                    
                    if !dragDirectionDetermined {
                        if totalDistance >= 8.0 {
                            dragDirectionDetermined = true
                            let isFromBottom = val.startLocation.y >= (screenH - (88.0 * uiScale))
                            let isMovingUpward = dy < 0
                            let isVerticalDominant = abs(dy) > abs(dx) * 1.3
                            
                            if isFromBottom && isMovingUpward && isVerticalDominant {
                                isDismissDragActive = true
                            } else {
                                isDismissDragActive = false
                                return
                            }
                        } else {
                            return
                        }
                    }
                    
                    guard isDismissDragActive else { return }
                    
                    if dy < 0 {
                        dragOffset = val.translation
                        let progress = min(1.0, max(0.0, -dy / 220.0))
                        appProgress = progress
                    } else {
                        dragOffset = CGSize(width: dx * 0.2, height: dy * 0.15)
                        appProgress = 0.0
                    }
                }
                .onEnded { val in
                    defer {
                        isDismissDragActive = false
                        dragDirectionDetermined = false
                    }
                    guard isDismissDragActive && !isDismissing else { return }
                    
                    let travelX = val.translation.width
                    let travelY = val.translation.height
                    let velocityY = val.predictedEndTranslation.height - val.translation.height
                    
                    let isVerticalEnd = abs(travelY) > abs(travelX) * 1.2
                    let isDistancePassed = travelY < -50
                    let isFlickPassed = (velocityY < -130) && (travelY < -25)
                    
                    if isVerticalEnd && (isDistancePassed || isFlickPassed) && travelY < 0 {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.82)) {
                            isDismissing = true
                            appProgress = 1.0
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.26) {
                            isActive = false
                        }
                    } else {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.78)) {
                            dragOffset = .zero
                            appProgress = 0.0
                        }
                    }
                }
        )
        .onAppear {
            appProgress = 0.0
            dragOffset = .zero
            isDismissing = false
            isDismissDragActive = false
            dragDirectionDetermined = false
        }
    }
}

// 📄 桌面主视图
struct HomeScreenView: View {
    @Binding var isUnlocked: Bool
    
    // =========================================================================
    // 🌟 单独调节状态栏高低位置（单位: pt）
    // 👉 正数（如 10.0、18.0）：状态栏向上提（更贴近屏幕顶端/灵动岛）
    // 👉 负数（如 -6.0、-12.0）：状态栏向下沉（更贴近桌面软件）
    // =========================================================================
    private let statusBarOffsetY: CGFloat = 10.0
    
    @StateObject private var viewModel = HomeScreenViewModel()
    @StateObject private var dragCoordinator = DragCoordinator()
    @StateObject private var widgetCoordinator = WidgetDragCoordinator()
    
    @ObservedObject var registry = WidgetRegistry.shared
    @ObservedObject var iconManager = CustomIconManager.shared
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    @State private var activeAppId: String? = nil
    @State private var currentPage = 0
    @State private var showAddWidgetSheet = false
    @State private var lastEditTriggerTime: Date = .distantPast
    @State private var showDotsTemporarily: Bool = false
    @State private var hideDotsTimer: Task<Void, Never>? = nil
    
    @State private var globalAppProgress: CGFloat = 0.0
    private let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
    var contentColor: Color { wallpaperManager.homeTextColor }
    
    // 🌟 自动识别壁纸色调（仅供 Dock 栏与搜索标签）
    @State private var isWhiteWallpaper: Bool = false
    
    var body: some View {
        GeometryReader { screenGeo in
            let screenW = screenGeo.size.width
            let screenH = screenGeo.size.height
            let rootOrigin = screenGeo.frame(in: .global).origin
            let s = uiScale
            
            // 骨架基准占位高
            let headerH: CGFloat = max(screenGeo.safeAreaInsets.top + (17.0 * s), 75.0 * s) - 2.0
            let jiggleHeadroom: CGFloat = 24.0 * s
            
            let dockH: CGFloat = 90.0 * s
            let dockBottom: CGFloat = max(screenGeo.safeAreaInsets.bottom - 10.0, 14.0 * s)
            let rowSpacing: CGFloat = 14.0 * s
            let rowPitch: CGFloat = (78.0 * s) + rowSpacing
            let widget2xHeight: CGFloat = (136.0 * s) + rowSpacing
            let widget4xHeight: CGFloat = (292.0 * s) + (3.0 * rowSpacing)
            let gridTotalHeight: CGFloat = (6.0 * 78.0 * s) + (5.0 * rowSpacing)
            let dockTriggerH = dockH + dockBottom + (20.0 * s)
            
            ZStack(alignment: .topLeading) {
                
                // 1. 最底层：静态壁纸
                HomeWallpaperBackgroundView()
                    .frame(width: screenW, height: screenH)
                    .ignoresSafeArea(.all)
                
                // 2. 桌面内容层：网格、图标、组件、Dock栏
                ZStack(alignment: .topLeading) {
                    VStack(spacing: 0) {
                        topHeaderContainerView(headerH: max(headerH - jiggleHeadroom, 30.0 * s))
                        
                        TabView(selection: $currentPage) {
                            ForEach(Array(0..<viewModel.totalPages()), id: \.self) { pageIndex in
                                DesktopPageView(
                                    pageIndex: pageIndex,
                                    screenW: screenW,
                                    screenH: screenH,
                                    rootOrigin: rootOrigin,
                                    headerH: headerH,
                                    rowPitch: rowPitch,
                                    widget2xHeight: widget2xHeight,
                                    widget4xHeight: widget4xHeight,
                                    dockTriggerH: dockTriggerH,
                                    contentColor: contentColor,
                                    viewModel: viewModel,
                                    dragCoordinator: dragCoordinator,
                                    widgetCoordinator: widgetCoordinator,
                                    registry: registry,
                                    iconManager: iconManager,
                                    currentPage: $currentPage,
                                    onLaunch: { handleAppLaunch($0) },
                                    onEnterEdit: enterEditMode,
                                    onExitEdit: exitEditMode,
                                    lastEditTriggerTime: lastEditTriggerTime
                                )
                                .padding(.top, jiggleHeadroom)
                                .tag(pageIndex)
                            }
                        }
                        .tabViewStyle(.page(indexDisplayMode: .never))
                        .frame(height: gridTotalHeight + jiggleHeadroom)
                        
                        // 覆盖 Dock 栏外围空白处
                        VStack(spacing: 0) {
                            Spacer(minLength: 24.0 * s)
                            
                            VStack(spacing: 24.0 * s) {
                                indicatorView
                                dockBarView(
                                    screenW: screenW,
                                    screenH: screenH,
                                    rootOrigin: rootOrigin,
                                    dockH: dockH,
                                    dockBottom: dockBottom,
                                    headerH: headerH,
                                    rowPitch: rowPitch,
                                    dockTriggerH: dockTriggerH
                                )
                            }
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .contentShape(Rectangle())
                        .onTapGesture {
                            guard Date().timeIntervalSince(lastEditTriggerTime) > 0.4 else { return }
                            if viewModel.isEditing { exitEditMode() }
                        }
                        .simultaneousGesture(
                            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                                if !viewModel.isEditing { enterEditMode() }
                            }
                        )
                    }
                    .frame(width: screenW, height: screenH)
                    
                    GlobalWidgetDragOverlay(
                        widgetCoordinator: widgetCoordinator,
                        tracker: widgetCoordinator.positionTracker,
                        screenW: screenW,
                        gridTopOffsetY: headerH,
                        widget4xHeight: widget4xHeight,
                        widget2xHeight: widget2xHeight
                    )
                    
                    ActiveDragOverlay(
                        coordinator: dragCoordinator,
                        tracker: dragCoordinator.positionTracker,
                        rootOrigin: rootOrigin,
                        screenH: screenH,
                        contentColor: contentColor
                    )
                }
                .overlay(homeIndicatorBar, alignment: .bottom)
                .blur(radius: activeAppId != nil ? ((1.0 - globalAppProgress) * 10.0) : 0.0)
                .scaleEffect(activeAppId != nil ? (0.94 + (globalAppProgress * 0.06)) : 1.0)
                
                // 3. 原生毛玻璃图层
                Rectangle()
                    .fill(.ultraThinMaterial)
                    .opacity(activeAppId != nil ? (1.0 - Double(globalAppProgress)) : 0.0)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                
                // 4. 顶层：运行中的 App 视窗
                if let activeId = activeAppId, let appDef = AppRegistry.shared.registeredApps[activeId] {
                    FluidIOSAppWindow(
                        screenW: screenW,
                        screenH: screenH,
                        isActive: Binding(
                            get: { activeAppId != nil },
                            set: { if !$0 { activeAppId = nil } }
                        ),
                        appProgress: $globalAppProgress
                    ) {
                        appDef.viewBuilder(.constant(true))
                    }
                    .ignoresSafeArea(.all)
                    .transition(.opacity)
                    .zIndex(999)
                }
            }
            .gesture(lockDragGesture)
        }
        .fontWeight(appearance.systemFontWeight)
        .ignoresSafeArea(.all)
        .ignoresSafeArea(.keyboard)
        .statusBarHidden(true)
        .persistentSystemOverlays(appearance.hideHomeIndicator ? .hidden : .automatic)
        .onAppear {
            AppAutoEngine.boot()
            viewModel.resolveAllWidgetOverlaps()
            viewModel.compactPages()
            currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
            checkWallpaperTone()
        }
        .onChange(of: wallpaperManager.homeScreenImage) { _, _ in
            checkWallpaperTone()
        }
        .onChange(of: wallpaperManager.homeScreenData) { _, _ in
            checkWallpaperTone()
        }
        .sheet(isPresented: $showAddWidgetSheet) {
            AddWidgetSheetView(
                isPresented: $showAddWidgetSheet,
                viewModel: viewModel,
                currentPage: $currentPage
            )
        }
    }
    
    // MARK: - 精准识别壁纸色调
    private func checkWallpaperTone() {
        let img = wallpaperManager.homeScreenImage ?? (wallpaperManager.homeScreenData != nil ? UIImage(data: wallpaperManager.homeScreenData!) : nil)
        guard let img = img else {
            self.isWhiteWallpaper = false
            return
        }
        
        DispatchQueue.global(qos: .userInitiated).async {
            let targetSize = CGSize(width: 24, height: 24)
            UIGraphicsBeginImageContextWithOptions(targetSize, false, 1.0)
            img.draw(in: CGRect(origin: .zero, size: targetSize))
            guard let smallImg = UIGraphicsGetImageFromCurrentImageContext(),
                  let cg = smallImg.cgImage else {
                UIGraphicsEndImageContext()
                return
            }
            UIGraphicsEndImageContext()
            
            guard let provider = cg.dataProvider,
                  let data = provider.data,
                  let ptr = CFDataGetBytePtr(data) else { return }
            
            let w = cg.width
            let h = cg.height
            let bpp = max(cg.bitsPerPixel / 8, 4)
            let bpr = cg.bytesPerRow
            
            var totalBrightness: Double = 0
            var totalSaturation: Double = 0
            var count: Double = 0
            
            var bottomBrightness: Double = 0
            var bottomSaturation: Double = 0
            var bottomCount: Double = 0
            
            for y in 0..<h {
                for x in 0..<w {
                    let offset = y * bpr + x * bpp
                    let r = Double(ptr[offset]) / 255.0
                    let g = Double(ptr[offset + 1]) / 255.0
                    let b = Double(ptr[offset + 2]) / 255.0
                    
                    let maxVal = max(r, max(g, b))
                    let minVal = min(r, min(g, b))
                    let brightness = (r * 0.299 + g * 0.587 + b * 0.114)
                    let saturation = maxVal == 0 ? 0 : (maxVal - minVal) / maxVal
                    
                    totalBrightness += brightness
                    totalSaturation += saturation
                    count += 1
                    
                    if y >= (h / 2) {
                        bottomBrightness += brightness
                        bottomSaturation += saturation
                        bottomCount += 1
                    }
                }
            }
            
            let avgB = count > 0 ? (totalBrightness / count) : 0
            let avgS = count > 0 ? (totalSaturation / count) : 0
            let btmB = bottomCount > 0 ? (bottomBrightness / bottomCount) : 0
            let btmS = bottomCount > 0 ? (bottomSaturation / bottomCount) : 0
            
            // 🌟 判定：全图或下部偏白，且饱和度不高
            let isWhite = (avgB > 0.62 && avgS < 0.35) || (btmB > 0.62 && btmS < 0.35)
            
            DispatchQueue.main.async {
                withAnimation(.easeInOut(duration: 0.22)) {
                    self.isWhiteWallpaper = isWhite
                }
            }
        }
    }
    
    // MARK: - 顶部状态栏与编辑栏
    private func topHeaderContainerView(headerH: CGFloat) -> some View {
        let s = uiScale
        return ZStack(alignment: .bottom) {
            if viewModel.isEditing {
                HStack {
                    Button(action: {
                        impactFeedback.impactOccurred()
                        showAddWidgetSheet = true
                    }) {
                        HStack(spacing: 4.0 * s) {
                            Image(systemName: "plus").font(.system(size: 11.0 * s, weight: appearance.systemFontWeight))
                            Text(lang.tr("edit")).font(.system(size: 13.0 * s, weight: appearance.systemFontWeight))
                        }
                        .foregroundColor(contentColor)
                        .padding(.horizontal, 12.0 * s)
                        .padding(.vertical, 4.0 * s)
                        // 使用安全物理隔离的方法
                        .applyLiquidGlassEffect(in: Capsule())
                        .clipShape(Capsule())
                    }
                    Spacer()
                    Button(action: { exitEditMode() }) {
                        Text(lang.tr("done"))
                            .font(.system(size: 13.0 * s, weight: appearance.systemFontWeight))
                            .foregroundColor(contentColor)
                            .padding(.horizontal, 14.0 * s)
                            .padding(.vertical, 4.0 * s)
                            .applyLiquidGlassEffect(in: Capsule())
                            .clipShape(Capsule())
                    }
                }
                .padding(.horizontal, 20.0 * s)
                .padding(.bottom, (6.0 + statusBarOffsetY) * s)
                .frame(height: headerH, alignment: .bottom)
                .applyCustomAppearance(appearance)
                .transition(.opacity)
            } else {
                HStack {
                    Text(lang.tr("carrier_name")).font(.system(size: 12.0 * s)).fontWeight(appearance.systemFontWeight)
                    Spacer()
                    Image(systemName: "wifi").font(.system(size: 14.0 * s))
                    Image(systemName: "battery.100").font(.system(size: 14.0 * s))
                }
                .foregroundColor(contentColor)
                .padding(.horizontal, 24.0 * s)
                .padding(.bottom, (6.0 + statusBarOffsetY) * s)
                .frame(height: headerH, alignment: .bottom)
                .opacity(appearance.hideStatusBar ? 0.0 : 1.0)
                .transition(.opacity)
            }
        }
        .frame(height: headerH, alignment: .bottom)
        .animation(.easeInOut(duration: 0.22), value: viewModel.isEditing)
        .animation(.easeInOut(duration: 0.22), value: appearance.hideStatusBar)
    }
    
    // MARK: - Dock 栏
    private func dockBarView(
        screenW: CGFloat,
        screenH: CGFloat,
        rootOrigin: CGPoint,
        dockH: CGFloat,
        dockBottom: CGFloat,
        headerH: CGFloat,
        rowPitch: CGFloat,
        dockTriggerH: CGFloat
    ) -> some View {
        let itemW = max(screenW - (26.0 * uiScale), 1) / 4.0
        let dockShape = RoundedRectangle(cornerRadius: 32.0 * uiScale, style: .continuous)
        
        return HStack(spacing: 0) {
            ForEach(Array(viewModel.dockApps.enumerated()), id: \.element.id) { index, item in
                DockItemView(
                    dockIndex: index,
                    item: item,
                    isEditing: viewModel.isEditing,
                    isBeingDragged: dragCoordinator.activeDraggingItem?.id == item.id,
                    customImageData: iconManager.getIcon(for: item.id),
                    onLaunch: { handleAppLaunch(item) },
                    onEnterEdit: enterEditMode,
                    onDragStart: { item, pos in
                        dragCoordinator.start(item: item, source: .dock(index), location: pos)
                    },
                    onDragChange: { pos in
                        dragCoordinator.update(location: pos)
                        let local = CGPoint(x: pos.x - rootOrigin.x, y: pos.y - rootOrigin.y)
                        dragCoordinator.handleEdgePaging(
                            localLocation: local,
                            screenW: screenW,
                            screenH: screenH,
                            dockTriggerH: dockTriggerH,
                            currentPage: $currentPage,
                            viewModel: viewModel
                        )
                        dragCoordinator.handleDockRealtimeSwap(
                            localLocation: local,
                            screenW: screenW,
                            screenH: screenH,
                            dockTriggerH: dockTriggerH,
                            viewModel: viewModel
                        )
                    },
                    onDragEnd: { pos in
                        dragCoordinator.finishDrag(
                            globalPos: pos,
                            rootOrigin: rootOrigin,
                            screenW: screenW,
                            screenH: screenH,
                            dockTriggerH: dockTriggerH,
                            headerH: headerH,
                            rowPitch: rowPitch,
                            currentPage: $currentPage,
                            viewModel: viewModel
                        )
                    }
                )
                .frame(width: itemW)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: dockH)
        // 🌟 使用全新隔层修饰器，绝不污染内部 App 原色
        .applyNativeAdaptiveGlass(isWhite: isWhiteWallpaper, in: dockShape)
        .contentShape(dockShape)
        .onTapGesture {
            guard Date().timeIntervalSince(lastEditTriggerTime) > 0.4 else { return }
            if viewModel.isEditing { exitEditMode() }
        }
        .simultaneousGesture(
            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                if !viewModel.isEditing { enterEditMode() }
            }
        )
        .padding(.horizontal, 13.0 * uiScale)
        .padding(.bottom, dockBottom)
        .applyCustomAppearance(appearance)
    }
    
    // MARK: - 分页指示器 / 搜索胶囊
    private var indicatorView: some View {
        let isDotsMode = (viewModel.totalPages() > 1) && (viewModel.isEditing || showDotsTemporarily)
        let activeColor = isWhiteWallpaper ? Color.black.opacity(0.72) : contentColor
        
        return ZStack {
            if isDotsMode {
                HStack(spacing: 5.5 * uiScale) {
                    ForEach(Array(0..<viewModel.totalPages()), id: \.self) { idx in
                        Circle()
                            .fill(activeColor.opacity(currentPage == idx ? 1.0 : 0.35))
                            .frame(width: 5.0 * uiScale, height: 5.0 * uiScale)
                    }
                }
                .padding(.horizontal, 8.0 * uiScale)
                .frame(height: 25.0 * uiScale)
                .transition(.opacity)
            } else {
                HStack(spacing: 3.0 * uiScale) {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 9.0 * uiScale, weight: appearance.systemFontWeight))
                    Text(lang.tr("search"))
                        .font(.system(size: 11.0 * uiScale, weight: appearance.systemFontWeight))
                }
                .foregroundColor(activeColor.opacity(0.95))
                .padding(.horizontal, 9.3 * uiScale)
                .frame(height: 25.0 * uiScale)
                .transition(.opacity)
            }
        }
        // 🌟 原生物理隔层
        .applyNativeAdaptiveGlass(isWhite: isWhiteWallpaper, in: Capsule())
        .clipShape(Capsule())
        .applyCustomAppearance(appearance)
        .animation(.spring(response: 0.28, dampingFraction: 0.85), value: isDotsMode)
        .frame(height: 25.0 * uiScale)
        .onChange(of: currentPage) { _, _ in
            guard !viewModel.isEditing && viewModel.totalPages() > 1 else { return }
            withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                showDotsTemporarily = true
            }
            hideDotsTimer?.cancel()
            hideDotsTimer = Task {
                try? await Task.sleep(nanoseconds: 1_200_000_000)
                guard !Task.isCancelled else { return }
                withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                    showDotsTemporarily = false
                }
            }
        }
    }
    
    private var homeIndicatorBar: some View {
        Capsule()
            .fill(contentColor.opacity(0.5))
            .frame(width: 130.0 * uiScale, height: 5.0 * uiScale)
            .padding(.bottom, 6.0 * uiScale)
            .opacity(appearance.hideHomeIndicator ? 0.0 : 1.0)
    }
    
    private var lockDragGesture: some Gesture {
        DragGesture(minimumDistance: 20.0 * uiScale)
            .onEnded { value in
                guard !viewModel.isEditing else { return }
                guard activeAppId == nil else { return }
                if value.translation.height > (50.0 * uiScale) {
                    withAnimation(.easeInOut(duration: 0.4)) {
                        isUnlocked = false
                    }
                }
            }
    }
    
    private func enterEditMode() {
        impactFeedback.impactOccurred()
        lastEditTriggerTime = Date()
        withAnimation(.easeInOut(duration: 0.22)) {
            viewModel.isEditing = true
        }
    }
    
    private func exitEditMode() {
        dragCoordinator.cancelEdgePaging()
        impactFeedback.impactOccurred()
        withAnimation(.easeInOut(duration: 0.22)) {
            viewModel.isEditing = false
            viewModel.compactPages()
            currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
        }
    }
    
    private func handleAppLaunch(_ item: AppItem) {
        if AppRegistry.shared.registeredApps.keys.contains(item.id) {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.92)) {
                activeAppId = item.id
            }
        } else {
            UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
        }
    }
}

// 📄 桌面页面视图
struct DesktopPageView: View {
    let pageIndex: Int
    let screenW: CGFloat
    let screenH: CGFloat
    let rootOrigin: CGPoint
    let headerH: CGFloat
    let rowPitch: CGFloat
    let widget2xHeight: CGFloat
    let widget4xHeight: CGFloat
    let dockTriggerH: CGFloat
    let contentColor: Color
    
    @ObservedObject var viewModel: HomeScreenViewModel
    @ObservedObject var dragCoordinator: DragCoordinator
    @ObservedObject var widgetCoordinator: WidgetDragCoordinator
    @ObservedObject var registry: WidgetRegistry
    @ObservedObject var iconManager: CustomIconManager
    
    @Binding var currentPage: Int
    let onLaunch: (AppItem) -> Void
    let onEnterEdit: () -> Void
    let onExitEdit: () -> Void
    let lastEditTriggerTime: Date
    
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 18.0 * uiScale), count: 4)
    }
    
    var body: some View {
        let fullWidth = max(0, screenW - (48.0 * uiScale))
        let halfWidth = max(0, (fullWidth - (18.0 * uiScale)) / 2.0)
        
        return ZStack(alignment: .topLeading) {
            LazyVGrid(columns: columns, spacing: 14.0 * uiScale) {
                ForEach(viewModel.slotsForPage(pageIndex), id: \.index) { slot in
                    GridSlotView(
                        slotIndex: slot.index,
                        item: slot.item,
                        isEditing: viewModel.isEditing,
                        isBeingDragged: dragCoordinator.activeDraggingItem?.id == slot.item?.id,
                        textColor: contentColor,
                        customTitle: slot.item != nil ? iconManager.getTitle(for: slot.item!.id) : nil,
                        customImageData: slot.item != nil ? iconManager.getIcon(for: slot.item!.id) : nil,
                        onLaunch: { if let item = slot.item { onLaunch(item) } },
                        onEnterEdit: onEnterEdit,
                        onDragStart: { item, pos in
                            dragCoordinator.start(item: item, source: .grid(slot.index), location: pos)
                        },
                        onDragChange: { pos in
                            dragCoordinator.update(location: pos)
                            let local = CGPoint(x: pos.x - rootOrigin.x, y: pos.y - rootOrigin.y)
                            dragCoordinator.handleEdgePaging(
                                localLocation: local,
                                screenW: screenW,
                                screenH: screenH,
                                dockTriggerH: dockTriggerH,
                                currentPage: $currentPage,
                                viewModel: viewModel
                            )
                            dragCoordinator.handleDockRealtimeSwap(
                                localLocation: local,
                                screenW: screenW,
                                screenH: screenH,
                                dockTriggerH: dockTriggerH,
                                viewModel: viewModel
                            )
                        },
                        onDragEnd: { pos in
                            dragCoordinator.finishDrag(
                                globalPos: pos,
                                rootOrigin: rootOrigin,
                                screenW: screenW,
                                screenH: screenH,
                                dockTriggerH: dockTriggerH,
                                headerH: headerH,
                                rowPitch: rowPitch,
                                currentPage: $currentPage,
                                viewModel: viewModel
                            )
                        }
                    )
                }
            }
            .zIndex(0)
            
            ForEach(registry.registeredWidgets) { widget in
                if widget.shouldRender(on: pageIndex) {
                    DraggableWidgetContainer(
                        widget: widget,
                        pageIndex: pageIndex,
                        screenW: screenW,
                        screenH: screenH,
                        rootOrigin: rootOrigin,
                        rowPitch: rowPitch,
                        dockTriggerH: dockTriggerH,
                        widget2xHeight: widget2xHeight,
                        widget4xHeight: widget4xHeight,
                        fullWidth: fullWidth,
                        halfWidth: halfWidth,
                        viewModel: viewModel,
                        dragCoordinator: dragCoordinator,
                        widgetCoordinator: widgetCoordinator,
                        currentPage: $currentPage
                    )
                }
            }
        }
        .padding(.horizontal, 24.0 * uiScale)
        .contentShape(Rectangle())
        .onTapGesture {
            guard Date().timeIntervalSince(lastEditTriggerTime) > 0.4 else { return }
            if viewModel.isEditing { onExitEdit() }
        }
        .simultaneousGesture(
            LongPressGesture(minimumDuration: 0.45).onEnded { _ in
                if !viewModel.isEditing { onEnterEdit() }
            }
        )
    }
}

// 📄 桌面单个可拖拽小组件容器
struct DraggableWidgetContainer: View {
    let widget: WidgetDefinition
    let pageIndex: Int
    let screenW: CGFloat
    let screenH: CGFloat
    let rootOrigin: CGPoint
    let rowPitch: CGFloat
    let dockTriggerH: CGFloat
    let widget2xHeight: CGFloat
    let widget4xHeight: CGFloat
    let fullWidth: CGFloat
    let halfWidth: CGFloat
    
    @ObservedObject var viewModel: HomeScreenViewModel
    @ObservedObject var dragCoordinator: DragCoordinator
    @ObservedObject var widgetCoordinator: WidgetDragCoordinator
    
    @Binding var currentPage: Int
    
    @GestureState private var dragActive: Bool = false
    private let impactFeedback = UIImpactFeedbackGenerator(style: .medium)
    
    var body: some View {
        let isBig = widget.sizeRows >= 4
        let isHalf = widget.sizeCols < 4
        let targetW = isHalf ? halfWidth : fullWidth
        let targetH = isBig ? widget4xHeight : widget2xHeight
        let offsetX: CGFloat = isHalf ? (widget.manager.widgetCol == 0 ? 0 : (halfWidth + (18.0 * uiScale))) : 0
        let offsetY: CGFloat = CGFloat(widget.manager.widgetRow) * rowPitch
        
        ZStack(alignment: .topLeading) {
            widget.desktopView()
            
            if viewModel.isEditing {
                Button(action: {
                    impactFeedback.impactOccurred()
                    withAnimation(.easeInOut(duration: 0.22)) {
                        widget.manager.isAddedToDesktop = false
                        viewModel.compactPages()
                        currentPage = min(currentPage, max(0, viewModel.totalPages() - 1))
                    }
                }) {
                    WidgetDeleteBadge()
                }
                .padding(8)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .modifier(JiggleModifier(
            isEditing: viewModel.isEditing,
            isWidget: true,
            customDelayIndex: abs(widget.id.hashValue) % 4
        ))
        .frame(width: targetW, height: targetH)
        .offset(x: offsetX, y: offsetY)
        .zIndex(1)
        .opacity(widgetCoordinator.activeWidgetId == widget.id ? 0.0 : 1.0)
        .transition(.identity)
        .id("widget_\(widget.id)_\(pageIndex)")
        .simultaneousGesture(
            DragGesture(minimumDistance: 8, coordinateSpace: .global)
                .updating($dragActive) { _, state, _ in state = true }
                .onChanged { val in
                    guard viewModel.isEditing else { return }
                    
                    if widgetCoordinator.activeWidgetId == nil {
                        impactFeedback.impactOccurred()
                        widgetCoordinator.start(widgetId: widget.id, originX: offsetX, originY: offsetY)
                    }
                    
                    widgetCoordinator.update(translation: val.translation)
                    
                    let local = CGPoint(x: val.location.x - rootOrigin.x, y: val.location.y - rootOrigin.y)
                    dragCoordinator.handleEdgePaging(
                        localLocation: local,
                        screenW: screenW,
                        screenH: screenH,
                        dockTriggerH: dockTriggerH,
                        currentPage: $currentPage,
                        viewModel: viewModel
                    )
                }
                .onEnded { _ in
                    guard viewModel.isEditing else { return }
                    finishDrag()
                }
        )
        .onChange(of: dragActive) { _, isActive in
            if !isActive && widgetCoordinator.activeWidgetId == widget.id {
                finishDrag()
            }
        }
    }
    
    private func finishDrag() {
        guard viewModel.isEditing else { return }
        widgetCoordinator.finishWidgetDrag(
            widgetDef: widget,
            screenW: screenW,
            rowPitch: rowPitch,
            currentPage: $currentPage,
            viewModel: viewModel
        )
    }
}
