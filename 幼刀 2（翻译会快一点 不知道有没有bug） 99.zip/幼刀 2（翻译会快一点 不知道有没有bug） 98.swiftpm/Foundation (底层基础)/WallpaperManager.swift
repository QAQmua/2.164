import SwiftUI
import CoreGraphics

// 📄 壁纸智能分析
extension UIImage {
    func analyzeWallpaperTone() -> (isLight: Bool, textColor: Color) {
        let width = 24
        let height = 24
        var pixelData = [UInt8](repeating: 0, count: width * height * 4)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        
        guard let context = CGContext(
            data: &pixelData,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: width * 4,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue
        ) else {
            return (false, .white)
        }
        
        context.interpolationQuality = .medium
        if let cgImg = self.cgImage {
            context.draw(cgImg, in: CGRect(x: 0, y: 0, width: width, height: height))
        } else {
            UIGraphicsPushContext(context)
            self.draw(in: CGRect(x: 0, y: 0, width: width, height: height))
            UIGraphicsPopContext()
        }
        
        var totalLuminance: Double = 0
        var validCount = 0
        let totalPixels = width * height
        
        for i in 0..<totalPixels {
            let offset = i * 4
            let a = Double(pixelData[offset + 3]) / 255.0
            if a > 0.25 {
                let r = Double(pixelData[offset]) / 255.0
                let g = Double(pixelData[offset + 1]) / 255.0
                let b = Double(pixelData[offset + 2]) / 255.0
                let lum = 0.299 * r + 0.587 * g + 0.114 * b
                totalLuminance += lum
                validCount += 1
            }
        }
        
        guard validCount > 0 else { return (false, .white) }
        let avgLum = totalLuminance / Double(validCount)
        return avgLum > 0.52 ? (true, Color(hex: "#1A1A1A")) : (false, .white)
    }
}

// 📄 壁纸管理中心
@MainActor
class WallpaperManager: ObservableObject {
    static let shared = WallpaperManager()
    
    private let lockImageIdKey = "App_LockWallpaper_ImageID"
    private let homeImageIdKey = "App_HomeWallpaper_ImageID"
    
    @Published var homeScreenImage: UIImage?
    @Published var lockScreenImage: UIImage?
    
    @Published var lockScreenData: Data? {
        didSet {
            self.lockScreenImage = ImageBitmapCache.shared.image(from: lockScreenData)
            updateTones()
            let oldId = UserDefaults.standard.string(forKey: lockImageIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: lockScreenData) { newId in
                UserDefaults.standard.set(newId, forKey: self.lockImageIdKey)
            }
        }
    }
    
    @Published var homeScreenData: Data? {
        didSet {
            self.homeScreenImage = ImageBitmapCache.shared.image(from: homeScreenData)
            updateTones()
            let oldId = UserDefaults.standard.string(forKey: homeImageIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: homeScreenData) { newId in
                UserDefaults.standard.set(newId, forKey: self.homeImageIdKey)
            }
        }
    }
    
    @Published var isLockLight: Bool = true
    @Published var isHomeLight: Bool = true
    @Published var homeTextColor: Color = Color(hex: "#1A1A1A")
    @Published var lockTextColor: Color = Color(hex: "#1A1A1A")
    
    init() {
        if let lockId = UserDefaults.standard.string(forKey: lockImageIdKey) {
            let data = LocalImageStore.shared.load(id: lockId)
            self.lockScreenData = data
            self.lockScreenImage = ImageBitmapCache.shared.image(from: data)
        }
        if let homeId = UserDefaults.standard.string(forKey: homeImageIdKey) {
            let data = LocalImageStore.shared.load(id: homeId)
            self.homeScreenData = data
            self.homeScreenImage = ImageBitmapCache.shared.image(from: data)
        }
        updateTones()
    }
    
    func updateTones() {
        if let img = lockScreenImage ?? (lockScreenData != nil ? UIImage(data: lockScreenData!) : nil) {
            let analysis = img.analyzeWallpaperTone()
            self.isLockLight = analysis.isLight
            self.lockTextColor = analysis.textColor
        } else {
            self.isLockLight = true
            self.lockTextColor = Color(hex: "#1A1A1A")
        }
        if let img = homeScreenImage ?? (homeScreenData != nil ? UIImage(data: homeScreenData!) : nil) {
            let analysis = img.analyzeWallpaperTone()
            self.isHomeLight = analysis.isLight
            self.homeTextColor = analysis.textColor
        } else {
            self.isHomeLight = true
            self.homeTextColor = Color(hex: "#1A1A1A")
        }
    }
}
