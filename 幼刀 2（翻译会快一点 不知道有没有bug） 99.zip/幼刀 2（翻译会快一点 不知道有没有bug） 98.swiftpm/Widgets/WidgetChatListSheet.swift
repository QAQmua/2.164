// 📄 完整替换文件：Widgets/WidgetChatListSheet.swift
import SwiftUI
import PhotosUI

// MARK: - 消息小卡片专属编辑面板
struct EditChatListWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var mgr = ChatListWidgetManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    @AppStorage("W_CL_PinPreview") private var isPreviewPinned: Bool = true
    @State private var selectedCategoryTab: Int = 0
    @State private var p1: PhotosPickerItem? = nil
    @State private var p2: PhotosPickerItem? = nil
    
    private var triggerKey: String { "\(selectedCategoryTab)" }
    
    private let colors = ["#000000", "#FFFFFF", "#3A3A3C", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let borderColors = ["#E5E5EA", "#000000", "#FFFFFF", "#8E8E93", "#007AFF", "#FF2D55", "#FF9500"]
    
    var body: some View {
        let s = uiScale
        NavigationStack {
            VStack(spacing: 0) {
                if isPreviewPinned {
                    pinnedHeaderView(s: s)
                        .overlay(alignment: .bottom) {
                            ZStack {
                                Rectangle().fill(.ultraThinMaterial)
                                LinearGradient(
                                    colors: [Color(UIColor.systemGroupedBackground), Color(UIColor.systemGroupedBackground).opacity(0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            }
                            .frame(height: 18)
                            .offset(y: 18)
                            .mask(
                                LinearGradient(
                                    stops: [.init(color: .black, location: 0.0), .init(color: .black.opacity(0.6), location: 0.4), .init(color: .clear, location: 1.0)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .allowsHitTesting(false)
                        }
                        .zIndex(10)
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !isPreviewPinned {
                            pinnedHeaderView(s: s)
                                .padding(.top, 10)
                        }
                        
                        if selectedCategoryTab == 0 {
                            styleCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        } else {
                            contentCategorySection()
                                .padding(.top, isPreviewPinned ? 14 : 0)
                        }
                    }
                    .padding(.bottom, 36)
                }
            }
            .background(Color(UIColor.systemGroupedBackground))
            .navigationTitle("消息小卡片 (2×2)".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                            isPreviewPinned.toggle()
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isPreviewPinned ? "pin.fill" : "pin.slash")
                                .font(.system(size: 13, weight: .semibold))
                            Text(isPreviewPinned ? "取消置顶".tr : "置顶预览".tr)
                                .font(.system(size: 13))
                        }
                        .foregroundColor(isPreviewPinned ? appearance.accentTextColor : .secondary)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                    .foregroundColor(appearance.accentTextColor)
                }
            }
            .task(id: p1) {
                if let d = try? await p1?.loadTransferable(type: Data.self) {
                    withAnimation { mgr.avatar1Data = d }
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                    p1 = nil
                }
            }
            .task(id: p2) {
                if let d = try? await p2?.loadTransferable(type: Data.self) {
                    withAnimation { mgr.avatar2Data = d }
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                    p2 = nil
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    // MARK: - 预览与分段器
    private func pinnedHeaderView(s: CGFloat) -> some View {
        VStack(spacing: 12) {
            ChatListWidget2x2View(manager: mgr, showDashedBorder: true)
                .frame(width: 155 * s, height: 155 * s)
                .shadow(color: .black.opacity(0.08), radius: 8, y: 3)
                .contentShape(Rectangle())
            
            Picker("", selection: $selectedCategoryTab.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                Text("样式".tr).tag(0)
                Text("内容".tr).tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 24)
        }
        .padding(.top, 10)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity)
        .background(Color(UIColor.systemGroupedBackground))
    }
    
    // MARK: - 样式分类
    private func styleCategorySection() -> some View {
        VStack(spacing: 16) {
            // 背景与时间
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("背景与同步".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("背景样式".tr).font(.system(size: 14, weight: appearance.systemFontWeight))
                        Picker("", selection: $mgr.bgColorMode) {
                            Text("纯白 (默认)".tr).tag("white")
                            Text("原版深黑".tr).tag("black")
                            Text("透明背景".tr).tag("transparent")
                        }
                        .pickerStyle(.segmented)
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    Toggle("自动同步现实日期与时间".tr, isOn: $mgr.autoFollowRealTime)
                        .font(.system(size: 15, weight: appearance.systemFontWeight))
                        .tint(appearance.toggleTintColor)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 头像与联系人描边
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("头像与行边框形态".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("头像圆角".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                            Spacer()
                            Text(mgr.avatarCornerRadius >= 13 ? "圆形 (默认)".tr : (mgr.avatarCornerRadius == 0 ? "直角".tr : String(format: "%.0f pt", mgr.avatarCornerRadius)))
                                .font(.caption).foregroundColor(.secondary)
                        }
                        Slider(value: $mgr.avatarCornerRadius, in: 0.0...14.0, step: 1.0)
                            .tint(appearance.sliderTrackColor)
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    Toggle(isOn: $mgr.hasItemCard.animation(.spring(response: 0.35, dampingFraction: 0.82))) {
                        Label("联系人列表圆框描边".tr, systemImage: "square.dashed")
                            .font(.system(size: 15, weight: appearance.systemFontWeight))
                    }
                    .tint(appearance.toggleTintColor)
                    
                    if mgr.hasItemCard {
                        VStack(alignment: .leading, spacing: 12) {
                            WidgetColorPaletteRow(title: "圆框底色".tr, selectedHex: mgr.itemCardBgHex, presets: colors, currentColor: Color(hex: mgr.itemCardBgHex), onSelectHex: { mgr.itemCardBgHex = $0 }, onPickColor: { mgr.itemCardBgHex = $0.toHex() })
                            
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("圆框圆角".tr).font(.system(size: 14, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%.0f pt", mgr.itemCardCornerRadius)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $mgr.itemCardCornerRadius, in: 2.0...16.0, step: 1.0)
                                    .tint(appearance.sliderTrackColor)
                            }
                            
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("描边粗细".tr).font(.system(size: 14, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%.1f pt", mgr.itemCardBorderWidth)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $mgr.itemCardBorderWidth, in: 0.4...3.0, step: 0.1)
                                    .tint(appearance.sliderTrackColor)
                            }
                            
                            WidgetColorPaletteRow(title: "描边颜色".tr, selectedHex: mgr.itemCardBorderHex, presets: borderColors, currentColor: Color(hex: mgr.itemCardBorderHex), onSelectHex: { mgr.itemCardBorderHex = $0 }, onPickColor: { mgr.itemCardBorderHex = $0.toHex() })
                        }
                        .padding(.top, 4)
                    }
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 字体配色
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    HStack {
                        Text("字体颜色配置".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                        Spacer()
                        if !mgr.mainTextColorHex.isEmpty || !mgr.subTextColorHex.isEmpty || !mgr.timeColorHex.isEmpty {
                            Button("恢复默认配色".tr) {
                                withAnimation {
                                    mgr.mainTextColorHex = ""
                                    mgr.subTextColorHex = ""
                                    mgr.timeColorHex = ""
                                }
                            }
                            .font(.caption)
                            .foregroundColor(.blue)
                        }
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    WidgetColorPaletteRow(title: "主要文字 (昵称/电量/星期)".tr, selectedHex: mgr.mainTextColorHex, presets: colors, currentColor: !mgr.mainTextColorHex.isEmpty ? Color(hex: mgr.mainTextColorHex) : (mgr.bgColorMode == "black" ? .white : .black), onSelectHex: { mgr.mainTextColorHex = $0 }, onPickColor: { mgr.mainTextColorHex = $0.toHex() })
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    WidgetColorPaletteRow(title: "消息正文颜色".tr, selectedHex: mgr.subTextColorHex, presets: colors, currentColor: !mgr.subTextColorHex.isEmpty ? Color(hex: mgr.subTextColorHex) : (mgr.bgColorMode == "black" ? .white.opacity(0.85) : Color(hex: "#2C2C2E")), onSelectHex: { mgr.subTextColorHex = $0 }, onPickColor: { mgr.subTextColorHex = $0.toHex() })
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 3, triggerKey: triggerKey) {
                    WidgetColorPaletteRow(title: "时间与日期颜色".tr, selectedHex: mgr.timeColorHex, presets: colors, currentColor: !mgr.timeColorHex.isEmpty ? Color(hex: mgr.timeColorHex) : Color(hex: "#8E8E93"), onSelectHex: { mgr.timeColorHex = $0 }, onPickColor: { mgr.timeColorHex = $0.toHex() })
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
    
    // MARK: - 内容分类
    private func contentCategorySection() -> some View {
        VStack(spacing: 16) {
            // 顶部栏
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("顶部栏配置".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("联系人搜索栏文本".tr).font(.caption2).foregroundColor(.secondary)
                        TextField("contact: // 456076", text: $mgr.contactText)
                            .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
                    }
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("电量文本".tr).font(.caption2).foregroundColor(.secondary)
                        TextField("如: 60%", text: $mgr.batteryText)
                            .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
                    }
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 第一位联系人
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("第一位联系人 (小雨呆咪)".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    contactAvatarRow(avatarData: mgr.avatar1Data, pickerItem: $p1, onClear: { mgr.avatar1Data = nil })
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    contactFieldsView(name: $mgr.name1, msg: $mgr.message1, time: $mgr.time1, status: $mgr.status1)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
            
            // 第二位联系人
            VStack(alignment: .leading, spacing: 14) {
                DominoScrollRevealWrapper(step: 0, triggerKey: triggerKey) {
                    Text("第二位联系人 (流泪猫猫头)".tr)
                        .font(.system(size: 13, weight: appearance.systemFontWeight))
                        .foregroundColor(.secondary)
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 1, triggerKey: triggerKey) {
                    contactAvatarRow(avatarData: mgr.avatar2Data, pickerItem: $p2, onClear: { mgr.avatar2Data = nil })
                }
                
                Divider()
                
                DominoScrollRevealWrapper(step: 2, triggerKey: triggerKey) {
                    contactFieldsView(name: $mgr.name2, msg: $mgr.message2, time: $mgr.time2, status: $mgr.status2)
                }
            }
            .padding(16)
            .background(Color(UIColor.secondarySystemGroupedBackground))
            .cornerRadius(18)
            .padding(.horizontal, 16)
        }
    }
    
    private func contactAvatarRow(avatarData: Data?, pickerItem: Binding<PhotosPickerItem?>, onClear: @escaping () -> Void) -> some View {
        HStack(spacing: 12) {
            ZStack {
                if let d = avatarData, let uiImg = UIImage(data: d) {
                    Image(uiImage: uiImg).resizable().scaledToFill()
                } else {
                    Color(UIColor.tertiarySystemFill)
                    Image(systemName: "person.fill").font(.system(size: 18)).foregroundColor(.secondary)
                }
            }
            .frame(width: 48, height: 48)
            .clipShape(Circle())
            
            PhotosPicker(selection: pickerItem, matching: .images, photoLibrary: .shared()) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(avatarData == nil ? "选取联系人头像".tr : "更换联系人头像".tr)
                        .font(.system(size: 15, weight: .medium)).foregroundColor(.primary)
                    Text("点击从相册设定头像".tr).font(.system(size: 12)).foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            
            if avatarData != nil {
                Button(action: {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation { onClear() }
                }) {
                    Image(systemName: "xmark.circle.fill").font(.system(size: 20)).foregroundColor(Color(UIColor.tertiaryLabel))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 8)
        .background(Color(UIColor.tertiarySystemFill).opacity(0.55)).cornerRadius(14)
    }
    
    private func contactFieldsView(name: Binding<String>, msg: Binding<String>, time: Binding<String>, status: Binding<String>) -> some View {
        VStack(spacing: 10) {
            TextField("输入昵称".tr, text: name)
                .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
            TextField("输入最新消息内容".tr, text: msg)
                .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
            HStack(spacing: 10) {
                if !mgr.autoFollowRealTime {
                    TextField("时间 (如: 09-25)".tr, text: time)
                        .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
                }
                TextField("状态标签 (如: 已读/未读)".tr, text: status)
                    .font(.subheadline).padding(10).background(Color(UIColor.tertiarySystemFill)).cornerRadius(10)
            }
        }
    }
}
