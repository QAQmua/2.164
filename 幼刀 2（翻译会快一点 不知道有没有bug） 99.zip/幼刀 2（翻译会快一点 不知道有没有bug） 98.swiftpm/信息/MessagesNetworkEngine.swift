// 📄 文件路径：信息/MessagesNetworkEngine.swift (100% 互通修复版)
import SwiftUI
import Foundation

// MARK: - 跨设备实时传输数据包协议 (Codable)
public enum IMMessagePacketType: String, Codable {
    case text           // 文本/富媒体消息
    case image          // 压缩图片消息
    case tapback        // 气泡点按回应 (❤️ 👍 👎 😂 ‼️ ❓)
    case typing         // 正在输入状态同步
    case readReceipt    // 已读回执同步
}

public struct IMNetworkPacket: Codable, Identifiable {
    public var id: String               // 消息唯一 UUID
    public var packetType: IMMessagePacketType
    public var senderID: String         // 发送方本机号码 (如 "839-201")
    public var senderName: String       // 发送方昵称
    public var senderAvatarBase64: String? // 发送方头像微缩图
    public var targetID: String         // 接收方号码
    public var textContent: String?     // 文字内容
    public var imageBase64: String?     // 图片数据 Base64
    public var replyToID: String?       // 引用回复的目标消息 ID
    public var replyPreview: String?    // 引用回复的文本预览
    public var tapbackSymbol: String?   // 点按回应符号
    public var sendEffect: String?      // 发送特效 ("slam", "loud", "gentle", "invisible")
    public var isTyping: Bool?          // 是否正在输入
    public var timestamp: TimeInterval  // 发送时间戳
}

// MARK: - Apple 原生双通道高可靠全球实时通信引擎
@MainActor
public final class MessagesNetworkEngine: ObservableObject {
    public static let shared = MessagesNetworkEngine()
    
    @Published public private(set) var isConnected: Bool = false
    @Published public private(set) var connectionStatusText: String = "正在连接 iMessage 云端..."
    
    private var webSocketTask: URLSessionWebSocketTask?
    private var backupSocketTask: URLSessionWebSocketTask?
    private var pingTimer: Timer?
    private var reconnectTask: Task<Void, Never>?
    private var pendingQueue: [IMNetworkPacket] = []
    private var receivedPacketIDs: Set<String> = []
    
    // 🌟 核心修复 1：同时连接 EMQX 与 HiveMQ 双主干网（双发双收，彻底解决两台设备连到不同服务器互发不通的问题！）
    private let primaryBroker = "wss://broker.emqx.io:8084/mqtt"
    private let backupBroker  = "wss://broker.hivemq.com:8884/mqtt"
    
    public var onReceivePacket: ((IMNetworkPacket) -> Void)?
    
    private let topicPrefix = "youdao_ios27_imessage_v2/peer/"
    private var currentSubscribedID: String = ""
    
    private init() {}
    
    // MARK: - 启动并同时订阅双云端本机专属号码信道
    public func connect(myDeviceID: String) {
        let cleanID = Self.normalizeID(myDeviceID)
        guard !cleanID.isEmpty else { return }
        
        if isConnected && currentSubscribedID == cleanID { return }
        currentSubscribedID = cleanID
        
        disconnect()
        connectionStatusText = "正在连接 iMessage 云端..."
        
        // 启动主信道 (EMQX)
        webSocketTask = createAndStartSocket(urlString: primaryBroker, cleanID: cleanID, isPrimary: true)
        // 启动辅信道 (HiveMQ) 双保险互通
        backupSocketTask = createAndStartSocket(urlString: backupBroker, cleanID: cleanID, isPrimary: false)
        
        startPingLoop()
    }
    
    private func createAndStartSocket(urlString: String, cleanID: String, isPrimary: Bool) -> URLSessionWebSocketTask? {
        guard let url = URL(string: urlString) else { return nil }
        var request = URLRequest(url: url)
        request.timeoutInterval = 10
        request.setValue("mqtt", forHTTPHeaderField: "Sec-WebSocket-Protocol")
        
        let session = URLSession(configuration: .default)
        let task = session.webSocketTask(with: request)
        task.resume()
        
        receiveLoop(for: task, isPrimary: isPrimary)
        
        Task {
            do {
                let tag = isPrimary ? "p" : "b"
                let clientID = "yd_\(tag)_\(cleanID)_\(Int.random(in: 10000...99999))"
                let connectData = buildMQTTConnectPacket(clientID: clientID)
                try await task.send(.data(connectData))
            } catch {
                if isPrimary { handleConnectionFailure() }
            }
        }
        return task
    }
    
    // 收到 CONNACK (0x20) 握手确认后订阅本机收件箱
    private func onHandshakeConfirmed(for task: URLSessionWebSocketTask, isPrimary: Bool) {
        Task {
            do {
                let myTopic = topicPrefix + currentSubscribedID
                let subscribeData = buildMQTTSubscribePacket(topic: myTopic, packetID: UInt16.random(in: 1...60000))
                try await task.send(.data(subscribeData))
                
                self.isConnected = true
                self.connectionStatusText = "iMessage 云端已就绪 (双通道)"
                flushPendingQueue()
            } catch {
                if isPrimary { handleConnectionFailure() }
            }
        }
    }
    
    public func disconnect() {
        pingTimer?.invalidate()
        pingTimer = nil
        reconnectTask?.cancel()
        reconnectTask = nil
        webSocketTask?.cancel(with: .goingAway, reason: nil)
        webSocketTask = nil
        backupSocketTask?.cancel(with: .goingAway, reason: nil)
        backupSocketTask = nil
        isConnected = false
    }
    
    // MARK: - 发送数据包给另一台设备（双主干网同步广播，必达！）
    public func sendPacket(_ packet: IMNetworkPacket) {
        let targetClean = Self.normalizeID(packet.targetID)
        guard !targetClean.isEmpty else { return }
        
        // 支持单机输入自己本机号自发自收测试
        if targetClean == currentSubscribedID {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                self.onReceivePacket?(packet)
            }
            return
        }
        
        guard isConnected else {
            if packet.packetType == .text || packet.packetType == .image || packet.packetType == .tapback {
                pendingQueue.append(packet)
            }
            connect(myDeviceID: currentSubscribedID)
            return
        }
        
        guard let jsonData = try? JSONEncoder().encode(packet) else { return }
        let targetTopic = topicPrefix + targetClean
        // 是否开启 Retain（文本与图片消息开启 Retain，防止对方瞬间闪断漏收）
        let shouldRetain = (packet.packetType == .text || packet.packetType == .image)
        let publishPacket = buildMQTTPublishPacket(topic: targetTopic, payload: jsonData, retain: shouldRetain)
        
        // 双通道同时发射，哪边通走哪边，接收端自动根据 packet.id 去重！
        webSocketTask?.send(.data(publishPacket)) { _ in }
        backupSocketTask?.send(.data(publishPacket)) { _ in }
    }
    
    private func flushPendingQueue() {
        guard isConnected, !pendingQueue.isEmpty else { return }
        let items = pendingQueue
        pendingQueue.removeAll()
        for pkt in items {
            sendPacket(pkt)
        }
    }
    
    private func handleConnectionFailure() {
        if backupSocketTask?.state != .running && webSocketTask?.state != .running {
            isConnected = false
            connectionStatusText = "云端重连中..."
            scheduleReconnect()
        }
    }
    
    // 标准化号码格式（去除所有非数字字母符号，比如把 "839-201" 变成 "839201"）
    public static func normalizeID(_ raw: String) -> String {
        let allowed = CharacterSet.alphanumerics
        let filtered = raw.unicodeScalars.filter { allowed.contains($0) }
        return String(String.UnicodeScalarView(filtered)).lowercased()
    }
    
    // MARK: - 持续监听下行消息
    private func receiveLoop(for task: URLSessionWebSocketTask?, isPrimary: Bool) {
        task?.receive { [weak self] result in
            guard let self = self else { return }
            Task { @MainActor in
                switch result {
                case .success(let message):
                    switch message {
                    case .data(let data):
                        if let t = task { self.parseIncomingMQTTData(data, task: t, isPrimary: isPrimary) }
                    case .string(let str):
                        if let data = str.data(using: .utf8), let t = task {
                            self.parseIncomingMQTTData(data, task: t, isPrimary: isPrimary)
                        }
                    @unknown default:
                        break
                    }
                    self.receiveLoop(for: task, isPrimary: isPrimary)
                case .failure:
                    if isPrimary { self.handleConnectionFailure() }
                }
            }
        }
    }
    
    private func startPingLoop() {
        pingTimer?.invalidate()
        pingTimer = Timer.scheduledTimer(withTimeInterval: 18.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            Task { @MainActor in
                let pingData = Data([0xC0, 0x00])
                self.webSocketTask?.send(.data(pingData)) { _ in }
                self.backupSocketTask?.send(.data(pingData)) { _ in }
            }
        }
    }
    
    private func scheduleReconnect() {
        reconnectTask?.cancel()
        reconnectTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            guard !Task.isCancelled else { return }
            if !self.currentSubscribedID.isEmpty {
                self.connect(myDeviceID: self.currentSubscribedID)
            }
        }
    }
    
    // MARK: - 轻量级原生 MQTT 二进制封包与多包拆包器
    private func buildMQTTConnectPacket(clientID: String) -> Data {
        var body = Data()
        body.append(contentsOf: [0x00, 0x04, 0x4D, 0x51, 0x54, 0x54]) // "MQTT"
        body.append(0x04) // Protocol Level 4 (v3.1.1)
        body.append(0x02) // Clean Session
        body.append(contentsOf: [0x00, 0x3C]) // Keep Alive 60s
        let idBytes = Array(clientID.utf8)
        body.append(UInt8((idBytes.count >> 8) & 0xFF))
        body.append(UInt8(idBytes.count & 0xFF))
        body.append(contentsOf: idBytes)
        
        var packet = Data([0x10])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func buildMQTTSubscribePacket(topic: String, packetID: UInt16) -> Data {
        var body = Data()
        body.append(UInt8((packetID >> 8) & 0xFF))
        body.append(UInt8(packetID & 0xFF))
        
        let topicBytes = Array(topic.utf8)
        body.append(UInt8((topicBytes.count >> 8) & 0xFF))
        body.append(UInt8(topicBytes.count & 0xFF))
        body.append(contentsOf: topicBytes)
        body.append(0x00) // QoS 0
        
        var packet = Data([0x82])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func buildMQTTPublishPacket(topic: String, payload: Data, retain: Bool) -> Data {
        var body = Data()
        let topicBytes = Array(topic.utf8)
        body.append(UInt8((topicBytes.count >> 8) & 0xFF))
        body.append(UInt8(topicBytes.count & 0xFF))
        body.append(contentsOf: topicBytes)
        body.append(payload)
        
        let headerByte: UInt8 = retain ? 0x31 : 0x30
        var packet = Data([headerByte])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func encodeRemainingLength(_ length: Int) -> Data {
        var encoded = Data()
        var x = length
        repeat {
            var byte = UInt8(x % 128)
            x = x / 128
            if x > 0 { byte = byte | 128 }
            encoded.append(byte)
        } while x > 0
        return encoded
    }
    
    // 🌟 核心修复 2：支持在单个 WebSocket 帧中循环解析多个粘在一起的 MQTT 报文！
    private func parseIncomingMQTTData(_ data: Data, task: URLSessionWebSocketTask, isPrimary: Bool) {
        let bytes = [UInt8](data)
        var cursor = 0
        
        while cursor < bytes.count {
            guard cursor + 2 <= bytes.count else { break }
            let header = bytes[cursor]
            let packetType = header & 0xF0
            cursor += 1
            
            var multiplier = 1
            var remainingLength = 0
            while cursor < bytes.count {
                let encodedByte = bytes[cursor]
                remainingLength += Int(encodedByte & 127) * multiplier
                multiplier *= 128
                cursor += 1
                if (encodedByte & 128) == 0 { break }
            }
            
            let packetEnd = min(cursor + remainingLength, bytes.count)
            
            if packetType == 0x20 {
                // CONNACK 握手成功
                onHandshakeConfirmed(for: task, isPrimary: isPrimary)
            } else if packetType == 0x30 {
                // PUBLISH 收到对方发来的数据包
                var innerIdx = cursor
                if innerIdx + 2 <= packetEnd {
                    let topicLen = (Int(bytes[innerIdx]) << 8) | Int(bytes[innerIdx + 1])
                    innerIdx += 2 + topicLen
                    
                    let qos = (header & 0x06) >> 1
                    if qos > 0 { innerIdx += 2 }
                    
                    if innerIdx < packetEnd {
                        let payloadData = Data(bytes[innerIdx..<packetEnd])
                        if let decoded = try? JSONDecoder().decode(IMNetworkPacket.self, from: payloadData) {
                            // 过滤超过 5 分钟的历史陈旧 Retain 包，并使用 ID 去重
                            if abs(Date().timeIntervalSince1970 - decoded.timestamp) < 300 {
                                if !receivedPacketIDs.contains(decoded.id) {
                                    if decoded.packetType != .typing {
                                        receivedPacketIDs.insert(decoded.id)
                                    }
                                    self.onReceivePacket?(decoded)
                                }
                            }
                        }
                    }
                }
            }
            
            cursor = packetEnd
        }
    }
}
