// 📄 文件路径：信息/MessagesView.swift
import SwiftUI
import PhotosUI

// MARK: - 1. 桌面插件自注册入口
final class MessagesAppPlugin: BaseAppPlugin {
    override class var id: String { "messages" }
    override class var name: String { "信息" }
    override class var icon: String { "message.badge.filled.fill" }
    override class var colorName: String { "green" }
    override class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(MessagesView(show: show))
    }
}

// MARK: - 2. iOS 26/27 纯原生信息主视图
@MainActor
struct MessagesView: View {
    @Binding var show: Bool
    @ObservedObject var viewModel = MessagesViewModel.shared
    @ObservedObject var netEngine = MessagesNetworkEngine.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    @State private var searchText: String = ""
    @State private var selectedFilter: String = "all"
    @State private var showComposeSheet: Bool = false
    @State private var showMyProfileSheet: Bool = false
    @State private var navPath = NavigationPath()
    
    private var pinnedConversations: [IMConversation] {
        filteredConversations.filter { $0.isPinned }
    }
    
    private var unpinnedConversations: [IMConversation] {
        filteredConversations.filter { !$0.isPinned }
    }
    
    private var filteredConversations: [IMConversation] {
        viewModel.conversations.filter { conv in
            let matchesSearch = searchText.trimmingCharacters(in: .whitespaces).isEmpty ||
            conv.name.localizedCaseInsensitiveContains(searchText) ||
            conv.peerID.localizedCaseInsensitiveContains(searchText) ||
            conv.lastMessageText.localizedCaseInsensitiveContains(searchText)
            guard matchesSearch else { return false }
            
            switch selectedFilter {
            case "unread": return conv.unreadCount > 0
            case "live": return !conv.isSMSChannel && !conv.isAIContact
            default: return true
            }
        }
    }
    
    private var displayedUnpinnedList: [IMConversation] {
        (searchText.isEmpty && selectedFilter == "all") ? unpinnedConversations : filteredConversations
    }
    
    var body: some View {
        let s = uiScale
        NavigationStack(path: $navPath) {
            List {
                // 1. iOS 原生置顶大头像网格区 (Pinned Conversations)
                if !pinnedConversations.isEmpty && searchText.isEmpty && selectedFilter == "all" {
                    Section {
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 14 * s), count: 3), spacing: 18 * s) {
                            ForEach(pinnedConversations) { conv in
                                Button {
                                    navPath.append(conv.id)
                                } label: {
                                    NativePinnedAvatarCell(conversation: conv)
                                }
                                .buttonStyle(.plain)
                                .contextMenu {
                                    Button {
                                        togglePin(conv.id)
                                    } label: {
                                        Label("取消置顶", systemImage: "pin.slash")
                                    }
                                    Button(role: .destructive) {
                                        deleteConversation(conv.id)
                                    } label: {
                                        Label("删除对话", systemImage: "trash")
                                    }
                                }
                            }
                        }
                        .padding(.vertical, 6 * s)
                    }
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
                }
                
                // 2. 标准原生会话列表
                Section {
                    ForEach(displayedUnpinnedList) { conv in
                        NavigationLink(value: conv.id) {
                            NativeConversationRow(conversation: conv)
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                            Button(role: .destructive) {
                                deleteConversation(conv.id)
                            } label: {
                                Label("删除", systemImage: "trash.fill")
                            }
                            
                            Button {
                                toggleMute(conv.id)
                            } label: {
                                Label(conv.isMuted ? "取消静音" : "静音", systemImage: conv.isMuted ? "bell.fill" : "bell.slash.fill")
                            }
                            .tint(.indigo)
                        }
                        .swipeActions(edge: .leading, allowsFullSwipe: true) {
                            Button {
                                togglePin(conv.id)
                            } label: {
                                Label(conv.isPinned ? "取消置顶" : "置顶", systemImage: conv.isPinned ? "pin.slash.fill" : "pin.fill")
                            }
                            .tint(.orange)
                            
                            Button {
                                toggleUnread(conv.id)
                            } label: {
                                Label("未读", systemImage: "message.badge.fill")
                            }
                            .tint(.blue)
                        }
                    }
                }
            }
            .listStyle(.plain)
            .navigationTitle(lang.tr("app_messages"))
            .navigationBarTitleDisplayMode(.large)
            .searchable(text: $searchText, prompt: "搜索")
            .navigationDestination(for: String.self) { convID in
                MessagesChatDetailView(conversationID: convID)
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Section("我的本机 iMessage 号码") {
                            Button {
                                showMyProfileSheet = true
                            } label: {
                                Label("本机号: \(viewModel.myDeviceID)", systemImage: "antenna.radiowaves.left.and.right")
                            }
                        }
                    } label: {
                        Text("编辑".tr)
                    }
                }
                
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Menu {
                        Picker("过滤信息", selection: $selectedFilter) {
                            Label("所有信息", systemImage: "message").tag("all")
                            Label("未读信息", systemImage: "circle.badge").tag("unread")
                            Label("跨设备直连", systemImage: "iphone.radiowaves.left.and.right").tag("live")
                        }
                    } label: {
                        Image(systemName: "line.3.horizontal.decrease")
                    }
                    
                    Button {
                        showComposeSheet = true
                    } label: {
                        Image(systemName: "square.and.pencil")
                    }
                }
            }
            .sheet(isPresented: $showComposeSheet) {
                NativeComposeNewMessageSheet { targetConvID in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                        navPath.append(targetConvID)
                    }
                }
            }
            .sheet(isPresented: $showMyProfileSheet) {
                NativeMyProfileSheet()
                    .presentationDetents([.medium])
            }
        }
        .preferredColorScheme(appearance.colorScheme)
    }
    
    private func togglePin(_ id: String) {
        guard let idx = viewModel.conversations.firstIndex(where: { $0.id == id }) else { return }
        withAnimation {
            viewModel.conversations[idx].isPinned.toggle()
            viewModel.saveConversations()
        }
    }
    
    private func toggleMute(_ id: String) {
        guard let idx = viewModel.conversations.firstIndex(where: { $0.id == id }) else { return }
        withAnimation {
            viewModel.conversations[idx].isMuted.toggle()
            viewModel.saveConversations()
        }
    }
    
    private func toggleUnread(_ id: String) {
        guard let idx = viewModel.conversations.firstIndex(where: { $0.id == id }) else { return }
        withAnimation {
            viewModel.conversations[idx].unreadCount = viewModel.conversations[idx].unreadCount > 0 ? 0 : 1
            viewModel.saveConversations()
        }
    }
    
    private func deleteConversation(_ id: String) {
        withAnimation {
            viewModel.conversations.removeAll(where: { $0.id == id })
            viewModel.saveConversations()
        }
    }
}

// MARK: - 原生置顶大头像单元格 (接入 uiScale)
struct NativePinnedAvatarCell: View {
    let conversation: IMConversation
    
    var body: some View {
        let s = uiScale
        VStack(spacing: 6 * s) {
            ZStack(alignment: .topTrailing) {
                NativeContactAvatarView(
                    name: conversation.name,
                    colorHex: conversation.avatarColorHex,
                    imageID: conversation.avatarImageID,
                    size: 72 * s
                )
                
                if conversation.unreadCount > 0 {
                    Text(conversation.lastMessageText)
                        .font(.system(size: 10 * s, weight: .medium))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                        .padding(.horizontal, 8 * s)
                        .padding(.vertical, 4 * s)
                        .frame(maxWidth: 88 * s)
                        .background(.regularMaterial, in: Capsule())
                        .offset(x: 8 * s, y: -8 * s)
                }
            }
            
            HStack(spacing: 4 * s) {
                if conversation.unreadCount > 0 {
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 7 * s, height: 7 * s)
                }
                Text(conversation.name)
                    .font(.system(size: 12 * s, weight: .medium))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
            }
        }
    }
}

// MARK: - 原生标准会话行 (接入 uiScale)
struct NativeConversationRow: View {
    let conversation: IMConversation
    
    var body: some View {
        let s = uiScale
        HStack(spacing: 12 * s) {
            Circle()
                .fill(conversation.unreadCount > 0 ? Color.blue : Color.clear)
                .frame(width: 9 * s, height: 9 * s)
            
            NativeContactAvatarView(
                name: conversation.name,
                colorHex: conversation.avatarColorHex,
                imageID: conversation.avatarImageID,
                size: 46 * s
            )
            
            VStack(alignment: .leading, spacing: 4 * s) {
                HStack(alignment: .firstTextBaseline) {
                    Text(conversation.name)
                        .font(.system(size: 16 * s, weight: .semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(1)
                    
                    Spacer()
                    
                    Text(relativeTimeString(conversation.lastTimestamp))
                        .font(.system(size: 14 * s))
                        .foregroundStyle(.secondary)
                }
                
                HStack {
                    Text(conversation.lastMessageText)
                        .font(.system(size: 14 * s))
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                    Spacer()
                    if conversation.isMuted {
                        Image(systemName: "bell.slash.fill")
                            .font(.system(size: 11 * s))
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .padding(.vertical, 2 * s)
    }
    
    private func relativeTimeString(_ date: Date) -> String {
        if date == Date.distantPast { return "" }
        let cal = Calendar.current
        let f = DateFormatter()
        if cal.isDateInToday(date) {
            f.dateFormat = "HH:mm"
        } else if cal.isDateInYesterday(date) {
            return "昨天"
        } else {
            f.dateFormat = "MM/dd"
        }
        return f.string(from: date)
    }
}

// MARK: - 通用原生圆形联系人头像视图
struct NativeContactAvatarView: View {
    let name: String
    let colorHex: String
    let imageID: String?
    let size: CGFloat
    
    var body: some View {
        Group {
            if let id = imageID,
               let data = LocalImageStore.shared.load(id: id),
               let uiImg = ImageBitmapCache.shared.image(from: data) {
                Image(uiImage: uiImg)
                    .resizable()
                    .scaledToFill()
            } else {
                ZStack {
                    Circle()
                        .fill(Color(hex: colorHex).gradient)
                    Text(String(name.prefix(1)))
                        .font(.system(size: size * 0.44, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
    }
}

// MARK: - 原生「新建信息」半屏 Sheet
@MainActor
struct NativeComposeNewMessageSheet: View {
    var onCreated: (String) -> Void
    @ObservedObject var viewModel = MessagesViewModel.shared
    @ObservedObject var netEngine = MessagesNetworkEngine.shared
    @Environment(\.dismiss) private var dismiss
    
    @State private var targetPeerID: String = ""
    @State private var targetRemarkName: String = ""
    @State private var firstMessageText: String = ""
    @FocusState private var isToFocused: Bool
    
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    HStack {
                        Text("收件人:")
                            .foregroundStyle(.secondary)
                        TextField("输入对方设备的号码 (如 839-201)", text: $targetPeerID)
                            .keyboardType(.asciiCapable)
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.never)
                            .focused($isToFocused)
                    }
                    
                    HStack {
                        Text("备注昵称:")
                            .foregroundStyle(.secondary)
                        TextField("选填 (如：爸比)", text: $targetRemarkName)
                    }
                } footer: {
                    Text("您的本机号码为：\(viewModel.myDeviceID)（\(netEngine.connectionStatusText)）。另一台安装了本项目的设备输入您的号码，即可跨网实时互发。")
                }
                
                Section("信息内容") {
                    TextField("iMessage信息", text: $firstMessageText, axis: .vertical)
                        .lineLimit(2...4)
                }
                
                Section {
                    Button("开始对话") {
                        startChat()
                    }
                    .disabled(targetPeerID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .navigationTitle("新信息")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { dismiss() }
                }
            }
            .onAppear { isToFocused = true }
        }
    }
    
    private func startChat() {
        let cleanPeer = targetPeerID.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanPeer.isEmpty else { return }
        let convID = viewModel.getOrCreateConversation(peerID: cleanPeer, customName: targetRemarkName)
        let msg = firstMessageText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !msg.isEmpty {
            viewModel.sendMessage(in: convID, text: msg)
        }
        dismiss()
        onCreated(convID)
    }
}

// MARK: - 本机 iMessage 名片与号码设置 Sheet
@MainActor
struct NativeMyProfileSheet: View {
    @ObservedObject var viewModel = MessagesViewModel.shared
    @ObservedObject var netEngine = MessagesNetworkEngine.shared
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            Form {
                Section("我的 iMessage 身份") {
                    LabeledContent("本机号码") {
                        Button {
                            UIPasteboard.general.string = viewModel.myDeviceID
                            UINotificationFeedbackGenerator().notificationOccurred(.success)
                        } label: {
                            HStack(spacing: 4) {
                                Text(viewModel.myDeviceID)
                                    .font(.system(.body, design: .monospaced).weight(.bold))
                                Image(systemName: "doc.on.doc")
                                    .font(.caption)
                            }
                        }
                    }
                    
                    LabeledContent("发送昵称") {
                        TextField("昵称", text: $viewModel.myDisplayName)
                            .multilineTextAlignment(.trailing)
                    }
                }
                
                Section("状态") {
                    LabeledContent("云端信道", value: netEngine.connectionStatusText)
                }
            }
            .navigationTitle("iMessage 名片")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }
}
